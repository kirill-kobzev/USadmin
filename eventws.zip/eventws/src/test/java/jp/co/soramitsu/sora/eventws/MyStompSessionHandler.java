package jp.co.soramitsu.sora.eventws;

import java.lang.reflect.Type;
import java.util.concurrent.CountDownLatch;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;

@Slf4j
@AllArgsConstructor
class MyStompSessionHandler extends StompSessionHandlerAdapter {

  private CountDownLatch latch;

  @Override
  public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
    log.info("I am connected!: {} {}", session.getSessionId(), connectedHeaders.getAcceptVersion());
    session.subscribe("/topic/greetings", new MyStompFrameHandler(latch, session));
  }

  @Override
  public void handleException(StompSession session, StompCommand command, StompHeaders headers,
      byte[] payload, Throwable exception) {
    log.info("Exception!", exception);
    latch.countDown();
    Assertions.fail(exception);
  }

  @Override
  public void handleTransportError(StompSession session, Throwable exception) {
    log.info("Transport error", exception);
    latch.countDown();
    Assertions.fail(exception);
  }

  @Override
  public Type getPayloadType(StompHeaders headers) {
    log.info("Returning String type");
    return String.class;
  }

  @Override
  public void handleFrame(StompHeaders headers, Object payload) {
    log.info("Got frame! Payload: {}", payload);
    latch.countDown();
  }
}
