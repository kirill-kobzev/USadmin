package jp.co.soramitsu.sora.eventws;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

import java.lang.reflect.Type;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import jp.co.soramitsu.sora.eventws.MyController.Greeting;
import jp.co.soramitsu.sora.eventws.MyController.HelloMessage;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompFrameHandler;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.socket.WebSocketHttpHeaders;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

@Slf4j
@SpringBootTest(webEnvironment = RANDOM_PORT)
@ExtendWith(SpringExtension.class)
public class SomeTest {

  @LocalServerPort
  private int port = 8080;
  private WebSocketStompClient stompClient;
  private WebSocketHttpHeaders headers = new WebSocketHttpHeaders();

  @BeforeEach
  public void setup() {
    this.stompClient = new WebSocketStompClient(new StandardWebSocketClient());
    this.stompClient.setMessageConverter(new MappingJackson2MessageConverter());
  }

  @Test
  public void getGreeting() throws Exception {

    final CountDownLatch latch = new CountDownLatch(1);
    final AtomicReference<Throwable> failure = new AtomicReference<>();

    StompSessionHandler handler = new TestSessionHandler(failure) {

      @Override
      public void afterConnected(final StompSession session, StompHeaders connectedHeaders) {
        session.subscribe("/topic/greetings", new StompFrameHandler() {
          @Override
          public Type getPayloadType(StompHeaders headers) {
            return Greeting.class;
          }

          @Override
          public void handleFrame(StompHeaders headers, Object payload) {
            val greeting = (Greeting) payload;
            try {
              assertEquals("Spring", greeting.getContent());
              log.info("Received msg: {}", payload);
            } catch (Throwable t) {
              failure.set(t);
            } finally {
              session.disconnect();
              latch.countDown();
            }
          }
        });
        try {
          session.send("/app/hello", new HelloMessage("Spring"));
        } catch (Throwable t) {
          failure.set(t);
          latch.countDown();
        }
      }
    };

    this.stompClient
        .connect("ws://localhost:{port}/ws", this.headers, handler, this.port);

    if (latch.await(3, TimeUnit.SECONDS)) {
      if (failure.get() != null) {
        throw new AssertionError("", failure.get());
      }
    } else {
      fail("Greeting not received");
    }

  }

  private class TestSessionHandler extends StompSessionHandlerAdapter {

    private final AtomicReference<Throwable> failure;


    public TestSessionHandler(AtomicReference<Throwable> failure) {
      this.failure = failure;
    }

    @Override
    public void handleFrame(StompHeaders headers, Object payload) {
      this.failure.set(new Exception(headers.toString()));
    }

    @Override
    public void handleException(StompSession s, StompCommand c, StompHeaders h, byte[] p,
        Throwable ex) {
      this.failure.set(ex);
    }

    @Override
    public void handleTransportError(StompSession session, Throwable ex) {
      this.failure.set(ex);
    }
  }

}
