package jp.co.soramitsu.sora.eventws;

import java.lang.reflect.Type;
import java.util.concurrent.CountDownLatch;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.stomp.StompFrameHandler;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;

@Slf4j
class MyStompFrameHandler implements StompFrameHandler {

  private CountDownLatch latch;

  public MyStompFrameHandler(CountDownLatch latch, StompSession session) {
    this.latch = latch;
    session.send("/app/hello", "somethings");
  }

  @Override
  public Type getPayloadType(StompHeaders headers) {
    return String.class;
  }

  @Override
  public void handleFrame(StompHeaders headers, Object payload) {
    log.info("Received frame: {}", payload);
    latch.countDown();
  }
}
