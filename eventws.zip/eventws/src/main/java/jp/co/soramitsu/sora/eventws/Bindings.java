package jp.co.soramitsu.sora.eventws;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;

public interface Bindings {
  interface Sink {

    @Input("/topic/greetings")
    SubscribableChannel topicGreetings();

  }

  interface Publish {

    @Output("/topic/greetings")
    MessageChannel topicGreetings();

  }
}
