package jp.co.soramitsu.sora.eventws;

import static lombok.AccessLevel.PRIVATE;

import java.lang.reflect.Type;
import javax.annotation.PostConstruct;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.SubscribableChannel;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompFrameHandler;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;
import org.springframework.stereotype.Controller;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

//@Controller
@Slf4j
public class MyController {

//  @MessageMapping("/topic/greetings")
//  public void greetingMessageMapping(Greeting msg) {
//    log.info("Got greeting {} from MessageMapping", msg);
//  }

//  @StreamListener(target = "/topic/greetings")
//  public void greetingsStreamListener(Greeting greeting) {
//    log.info("Got greeting {} from rabbit", greeting);
//  }

  /* @SubscribeMapping("/topic/greetings")
   public void greetingSubscribeMapping(Greeting msg) {
     log.info("Got greeting {} from SubscribeMapping", msg);
   }
 */
//  private WebSocketStompClient client;
  @Autowired
  private SimpMessagingTemplate template;
//  private static SimpMessagingTemplate session;

//  @PostConstruct
//  void init() {
//    client = new WebSocketStompClient(new StandardWebSocketClient());
//    client.setMessageConverter(new MappingJackson2MessageConverter());
//    client.connect("ws://localhost:61613", handler);
//  }
//
//  private StompSessionHandler handler = new StompSessionHandlerAdapter() {
//    @Override
//    public Type getPayloadType(StompHeaders headers) {
//      return Greeting.class;
//    }
//
//    @Override
//    public void handleFrame(StompHeaders headers, Object payload) {
//      log.info("Got frame: {}", payload);
//      super.handleFrame(headers, payload);
//    }
//
//    @Override
//    public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
//      super.afterConnected(session, connectedHeaders);
//      MyController.session = session;
//    }
//
//    @Override
//    public void handleException(StompSession session, StompCommand command, StompHeaders headers,
//        byte[] payload, Throwable exception) {
//      super.handleException(session, command, headers, payload, exception);
//      throw new RuntimeException(exception);
//    }
//
//    @Override
//    public void handleTransportError(StompSession session, Throwable exception) {
//      super.handleTransportError(session, exception);
//      throw new RuntimeException(exception);
//    }
//  };

  @Autowired
  @Qualifier("/topic/greetings")
  private SubscribableChannel topicGreetingsChannel;

  @StreamListener("/topic/greetings")
  public void consume(Object someEvent) {
    log.info("Got some event: {}");
    template.convertAndSend("/topic/greetings", someEvent);
  }


  @Data
  @FieldDefaults(level = PRIVATE)
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Greeting {

    String content;

  }

  @Data
  @FieldDefaults(level = PRIVATE)
  @AllArgsConstructor
  @NoArgsConstructor
  public static class HelloMessage {

    String name;

  }

}
