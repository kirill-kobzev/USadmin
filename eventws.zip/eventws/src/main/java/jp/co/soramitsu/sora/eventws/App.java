package jp.co.soramitsu.sora.eventws;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.socket.config.annotation.EnableWebSocket;

@SpringBootApplication
@Slf4j
@EnableBinding(Bindings.Sink.class)
public class App {

  public static void main(String[] args) {
    SpringApplication.run(App.class, args);
  }

}
