package jp.co.soramitsu.sora.eventws;

import static org.springframework.messaging.support.MessageBuilder.withPayload;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.List;
import javax.annotation.PostConstruct;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.context.IntegrationObjectSupport;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.SubscribableChannel;
import org.springframework.messaging.converter.MessageConverter;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.messaging.support.MessageBuilder;

@Configuration
@Slf4j
public class RabbitStompBridgeConfig {

  @Autowired
  private List<SubscribableChannel> messageChannels;

  @Autowired
  private SimpMessagingTemplate template;

  @Autowired
  private ObjectMapper objectMapper;

  @PostConstruct
  void init() {
    template.setMessageConverter(new MessageConverter() {
      @Override
      public Object fromMessage(Message<?> message, Class<?> targetClass) {
        throw new UnsupportedOperationException("MessageConverter#fromMessage is not supported");
      }

      @Override
      @SneakyThrows
      public Message<?> toMessage(Object payload, MessageHeaders headers) {
        return withPayload(payload)
            .copyHeaders(headers)
            .setHeader("content-type", "application/json;charset=UTF8")
            .build();
      }
    });

    messageChannels.forEach(channel -> {
      if (channel instanceof IntegrationObjectSupport) {
        val asBean = (IntegrationObjectSupport) channel;
        val channelName = asBean.getComponentName();
        log.info("Subscribing to channel {}", channelName);
        if (channelName.startsWith("/user")) {
          channel.subscribe(message -> sendToUser(channelName, message));
        } else {
          channel.subscribe(message -> sendToChannel(channelName, message));
        }
      }
    });
  }

  @SneakyThrows
  private void sendToChannel(String channel, Message<?> msg) {
    val msgId = msg.getHeaders().getId();
    log.trace("[id={}] Message body: {}", msgId, msg.getPayload());
    log.trace("[id={}] Message headers: {}", msgId, msg.getHeaders());
    log.debug("Forwarding message {} to channel {}...", msgId, channel);
    val stompHeaders = new HashMap<>(msg.getHeaders());
    stompHeaders.put("content-type", stompHeaders.get("contentType"));

    template.convertAndSend(channel, msg.getPayload(), stompHeaders);
  }

  private String getPayload(Message<?> msg) {
    return StringUtils.newStringUtf8((byte[]) msg.getPayload());
  }

  private void sendToUser(String channel, Message<?> msg) {
    log.debug("Forwarding message {} to channel {}...", msg.getHeaders().getId(), channel);
    val recipient = msg.getHeaders().get("recipient", String.class);
    if (recipient == null) {
      log.warn(
          "Channel name ({}) suggests message is addressed to specific user, but 'recipient' header is missing! Message will not be forwarded to STOMP relay!",
          channel);
      return;
    }
    log.debug("Received msg {} addressed to recipient {}", msg.getPayload(), recipient);
    val stompChannel = channel.substring("/user".length());
    log.info("Message to user is forwarded to {} STOMP relay channel", stompChannel);

    template.convertAndSendToUser(recipient, stompChannel, msg.getPayload(), msg.getHeaders());
  }

}
