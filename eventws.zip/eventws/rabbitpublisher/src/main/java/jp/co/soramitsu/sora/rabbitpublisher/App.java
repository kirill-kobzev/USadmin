package jp.co.soramitsu.sora.rabbitpublisher;

import java.lang.reflect.Type;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.PostConstruct;
import jp.co.soramitsu.sora.eventws.Bindings;
import jp.co.soramitsu.sora.eventws.MyController.Greeting;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.ReactorNettyTcpStompClient;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompFrameHandler;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.socket.WebSocketHttpHeaders;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

@SpringBootApplication
@EnableBinding(Bindings.Publish.class)
@EnableScheduling
@Slf4j
public class App {

  public static void main(String[] args) {
    SpringApplication.run(App.class, args);
  }

  @Autowired
  @Qualifier("/topic/greetings")
  private MessageChannel topicGreetings;

  private WebSocketStompClient client;
  private ReactorNettyTcpStompClient tcpStompClient;
  private static StompSession session;

  @PostConstruct
  void init() {
//    tcpStompClient = new ReactorNettyTcpStompClient("localhost", 61613);
//    tcpStompClient.setMessageConverter(new MappingJackson2MessageConverter());
//    val headers = new StompHeaders();
//    headers.setLogin("guest");
//    headers.setPasscode("guest");
//    tcpStompClient.connect(headers, handler);

    client = new WebSocketStompClient(new StandardWebSocketClient());
    client.setMessageConverter(new MappingJackson2MessageConverter());
    client.connect("ws://localhost:8080/ws", handler);
  }

  private StompSessionHandler handler = new StompSessionHandlerAdapter() {
      @Override
      public Type getPayloadType(StompHeaders headers) {
        return String.class;
      }

      @Override
      public void handleFrame(StompHeaders headers, Object payload) {
        log.info("Got frame: {}", payload);
        super.handleFrame(headers, payload);
      }

      @Override
      public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
        super.afterConnected(session, connectedHeaders);
        App.session = session;
        session.subscribe("/topic/greetings", new StompFrameHandler() {
          @Override
          public Type getPayloadType(StompHeaders headers) {
            return Greeting.class;
          }

          @Override
          public void handleFrame(StompHeaders headers, Object payload) {
            log.info("Received frame: {}", payload);
          }
        });
      }

      @Override
      public void handleException(StompSession session, StompCommand command, StompHeaders headers,
          byte[] payload, Throwable exception) {
        super.handleException(session, command, headers, payload, exception);
        log.error("Some exception, huh?", exception);
      }

      @Override
      public void handleTransportError(StompSession session, Throwable exception) {
        super.handleTransportError(session, exception);
        log.error("Some transport error", exception);
      }
    };

  @Scheduled(cron = "* * * * * * ")
  public void sendToRabbit() {
    topicGreetings.send(new GenericMessage<>(new Greeting("From Rabbit")));
  }

}
